function myfunction(){
    a=document.getElementByIagname("input");
    alert(a[0].value);
    alert(a[1].value);

}